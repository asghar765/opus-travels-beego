import { NextResponse } from 'next/server';
import { duffel } from '@/lib/duffel';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const query = searchParams.get('query');

  if (!query) {
    return NextResponse.json({ error: 'Query parameter is required' }, { status: 400 });
  }

  try {
    // First try to search by query
    const airportsResponse = await duffel.airports.list({
      query: query,
      limit: 5,
    });

    // If no results, try searching by IATA code
    if (airportsResponse.data.length === 0 && query.length === 3) {
      const iataResponse = await duffel.airports.get(query.toUpperCase());
      if (iataResponse.data) {
        return NextResponse.json([{
          code: iataResponse.data.iata_code,
          name: iataResponse.data.name,
          city: iataResponse.data.city?.name || '',
          country: iataResponse.data.city?.country?.name || '',
          type: 'airport'
        }]);
      }
    }

    // Format and return the results
    const formattedAirports = airportsResponse.data
      .filter(airport => airport.iata_code) // Only return airports with IATA codes
      .map(airport => ({
        code: airport.iata_code,
        name: airport.name,
        city: airport.city?.name || '',
        country: airport.city?.country?.name || '',
        type: 'airport'
      }));

    return NextResponse.json(formattedAirports);
  } catch (error) {
    console.error('Airport search error:', error);
    return NextResponse.json({ error: 'Failed to search airports' }, { status: 500 });
  }
}